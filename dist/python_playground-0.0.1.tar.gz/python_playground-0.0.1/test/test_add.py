from python_playground import add

def test_add():
    assert add.add(1, 2) == 3
